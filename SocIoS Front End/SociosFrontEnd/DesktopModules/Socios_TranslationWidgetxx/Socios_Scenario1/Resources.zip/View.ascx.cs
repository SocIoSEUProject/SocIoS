/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using SociosServices;
using System.Web.UI.WebControls;
using System.Collections;
using System.Collections.Generic;
using SociosServices.SocialFilteringGroupService2;
using SociosServices.TokenService;

namespace DotNetNuke.Modules.Socios_Scenario1
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewSocios_Scenario1 class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Socios_Scenario1ModuleBase, IActionable
    {

        #region Event Handlers
        string groupSession = "";
        SociosServices.SocialFilteringGroupService2.ObjectId groupSessionObj = new SociosServices.SocialFilteringGroupService2.ObjectId(); 
        GroupServiceClient groupClient = new GroupServiceClient();
        EventDetectionServiceClient eventDetectionClient = new EventDetectionServiceClient();
        ReputationServiceClient reputationClient = new ReputationServiceClient();
        RecommendationServiceClient recommendationClient = new RecommendationServiceClient();
        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }
        ArrayList urls = new ArrayList();

        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                lbl_Notification.Visible = false;
                lbl_Notification.Text = "";
                // TESTING
              string score =  GetPersonReputationScore("100001570512130");
              SociosServices.RecommendationService.Person[] persons = GetRecommendedPersons("birthday");
                    
                    
                    // GetProfileUrl();
                //CheckAccessTokensStatus();
                // Create a session object for the grouping service
                // Should remain the same in each session of SAME user
                
                    string groupSession = "GRP_SSSION_" + UserId;
                    groupSessionObj.id = groupSession;
                    groupSessionObj.source = new Source();
                    groupSessionObj.source.knownSns = KnownSns.FACEBOOK;

                    if(ddlAllGroups.Items.Count == 0)
                    {
                        LoadGroupsToDropDownList(ddlAllGroups);
                    }
                Page.ClientScript.RegisterClientScriptInclude("Scenario1.js", this.TemplateSourceDirectory + "/js/Scenario1.js");
                txtConsentFormText.Text = "Dear user, I would like to invite you to share... by visting the link http://frontend.sociosproject.eu. For more information, please refer to:  http://frontend.sociosproject.eu";
                txtConsentFrom.Text = "Me";
                txtConsentTo.Text = "User451";

                if (Request.QueryString["widget"] != null)
                {
                    lnkbtn_MenuShowManageGroups.Visible = false;
                    lnkbtn_MenuShowSearchMedia.Visible = false;
                    pnl_MediaSearch.Visible = true;
                    pnl_SortingLinks.Visible = false;
                    main_container.CssClass = "widg-main-container";
                }
                else
                {
                    main_container.CssClass = "main-container";
                }



                CheckFlexipriceStatus();

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        /// <summary>
        /// Loading Flexiprice link token and letting user know if he has pending
        // transactions
        /// </summary>
        protected void CheckFlexipriceStatus()
        {
            SociosServices.FlexiPriceClient flexiClient = new FlexiPriceClient();

            KeyValuePair<string, bool> urlAndFlag = flexiClient.GetTransactionsUrlAndFlag();

            string getTransactionUrl = "http://epart.atc.gr/flexiprice/?token=" + urlAndFlag.Key;
            bool userHasPendingTransactions = urlAndFlag.Value;
            if (userHasPendingTransactions)
            {
                lbl_PendingTransactions.Visible = true;
                lbl_NoPendingTransactions.Visible = false;
            }
            else
            {
                lbl_PendingTransactions.Visible = false;
                lbl_NoPendingTransactions.Visible = true;
            }

            hprlnk_goToFlexiprice.NavigateUrl = getTransactionUrl;
        }

        #endregion

        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                String[] searchTerms = txtSearch.Text.Split(' ');

                //// Core Services
                //var coreClient = new CoreServicesClient();
                //var items = coreClient.FindMediaItems(searchTerms);

                // Direct YouTube
                //var searchClient = new YouTubeClient();
                //var items = searchClient.FindMediaItems(searchTerms);

                //// Skeleton Services

                SkeletonServiceClient client = new SociosServices.SkeletonServiceClient();
                List<string> keywords = new List<string>();
                //keywords.Add("xbox");
                string[] words = keywords.ToArray();

                int userId = Convert.ToInt32(txtUserId.Text);

                List<SociosServices.WebSkeletonServiceLive.KnownSns> sources = new List<SociosServices.WebSkeletonServiceLive.KnownSns>();
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.DAILYMOTION);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.FACEBOOK);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.FLICKR);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.MYSPACE);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.TWITTER);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.YOUTUBE);

                var items = client.FindMediaItems(searchTerms, userId, sources);

                if (Request.QueryString["widget"] != null)
                {
                    widg_lstvwMediaItems.DataSource = items;
                    widg_lstvwMediaItems.DataBind();
                    widg_lstvwMediaItems.Visible = true;

                }
                else
                {
                    lstvwMediaItems.DataSource = items;
                    lstvwMediaItems.DataBind();
                    lstvwMediaItems.Visible = true;

                }
                foreach (SociosServices.WebSkeletonServiceLive.MediaItem item in items)
                {

                    //item.Url =item.Url.Split('?')[1].Split('&')[0].Replace("v=", "");

                }

                
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
        }



        protected void lstvwMediaItems_ItemCommand(object sender, System.Web.UI.WebControls.ListViewCommandEventArgs e)
        {
            if (e.CommandName == "sendMessage")
            {
                TextBox messageBox = (TextBox)e.Item.FindControl("txtConsentFormText");

                TextBox fromBox = (TextBox)e.Item.FindControl("txtConsentFrom");
                string message = messageBox.Text;
                if (message.Length > 500)
                {
                    message = message.Substring(0, 498);
                }

                var client = new YouTubeClient();
                string videoId = e.CommandArgument.ToString().Replace("http://www.youtube.com/embed/", "");
                //String authToken = "1/l8qdMd-uGld-qDPX-ywB5odnJUDCrXD4Bhkmgm4JL1c";
               // String authToken = "1/bz_nvk-v7aA4BcSRhJDd8H1HnmfljomTXVQEjCBKWFs";
                
                //String videoUrl = "ZqYslYcLjUM";
                client.addMessage(fromBox.Text, videoId, message);
            }
            else if (e.CommandName == "AssignPrice")
            {
                SociosServices.FlexiPriceClient flexiClient = new FlexiPriceClient();
                int user_id = UserId;
                string realName = UserInfo.DisplayName;
                string mediaItemId = "";
                string itemName = "";
                int ownerId = 3;
                string token = flexiClient.AssignPrice(user_id, realName, mediaItemId, itemName, ownerId);
                string assignPriceUrl = "http://epart.atc.gr/flexiprice/?token=" + token;
                Response.Redirect(assignPriceUrl);
            }
            else if (e.CommandName == "GetProfileUrl")
            {
                string[] itemUserInfo = e.CommandArgument.ToString().Split(':');
                if (itemUserInfo.Length > 1)
                {
                    //string userSnsId =
               // GetProfileUrl(e.CommandArgument.ToString().Split(':')[0], e.CommandArgument.ToString().Split(':')[1]);
          
                }
                  }
        }

        protected void LinkButton9_Click(object sender, EventArgs e)
        {
            String authToken = "1/bz_nvk-v7aA4BcSRhJDd8H1HnmfljomTXVQEjCBKWFs";

            var client = new YouTubeClient();
            //var persons = client.GetConnectedPersons(authToken);

        }

        public string GetProfileUrl(object sociosUserInfo)
        {
            string[] itemUserInfo = sociosUserInfo.ToString().Split(':');
            if (itemUserInfo.Length > 1)
            {
                string lowerSource = itemUserInfo[1].ToLower();
                string userSnsId = itemUserInfo[0];
                //string userSnsId =
                //GetProfileUrl(e.CommandArgument.ToString().Split(':')[0], e.CommandArgument.ToString().Split(':')[1]);
                if (lowerSource == "facebook")
                {
                    return "http://www.facebook.com/" + userSnsId;
                }
                else if (lowerSource == "flickr")
                {
                    return "http://www.flickr.com/people/" + userSnsId;
                }
                else if (lowerSource == "youtube")
                {
                    return "http://www.youtube.com/user/" + userSnsId;
                }
                
            }
            return "#";
            //string myScript = "";
            //myScript += "alert('" + userSnsId + ":" + source + "');";

            //Page.ClientScript.RegisterStartupScript(this.GetType(), "myKey", myScript, true);

           

            
        }

        protected void lnkbtn_MyGroups_Click(object sender, EventArgs e)
        {
            LoadAllGroups();
            LoadGroupsToDropDownList(ddlAllGroups);
        }

        protected void lnkbtn_AddNewGroup_Click(object sender, EventArgs e)
        {
            SociosServices.SocialFilteringGroupService2.Group test =
            CreateNewGroup(txt_NewGroupTitle.Text, txt_NewGroupDescription.Text);
            LoadAllGroups();
            LoadGroupsToDropDownList(ddlAllGroups);

        }

        protected SociosServices.SocialFilteringGroupService2.Group CreateNewGroup(string title, string description)
        {
            try
            {
                return groupClient.CreateGroup(groupSessionObj, title, description);
                 
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        protected void LoadAllGroups()
        {
            try
            {
                SociosServices.SocialFilteringGroupService2.Group[] groups = groupClient.GetGroups(groupSessionObj);
                lstvw_AllGroups.DataSource = groups;
                foreach (SociosServices.SocialFilteringGroupService2.Group item in groups)
                {
                    //item.Url =item.Url.Split('?')[1].Split('&')[0].Replace("v=", "");
                }
                lstvw_AllGroups.DataBind();
            }
            catch (Exception ex)
            {
                string error = ex.StackTrace;
            }
        }

        protected void LoadGroupsToDropDownList(DropDownList ddlToPopulate)
        {
            SociosServices.SocialFilteringGroupService2.Group[] groups = groupClient.GetGroups(groupSessionObj);
            ListItemCollection items = new ListItemCollection();
            ddlToPopulate.Items.Clear();
            foreach (SociosServices.SocialFilteringGroupService2.Group group in groups)
            {
                ListItem newItem = new ListItem(group.title, group.id.id);
                ddlToPopulate.Items.Add(newItem);
            }
        }

        protected SociosServices.SocialFilteringGroupService2.Person[] GetGroupPeople(string groupObjectId)
        {
           return groupClient.GetGroupMembers(groupSessionObj, groupObjectId);
        }

       

        protected void lstvw_AllGroups_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            
            if (e.CommandName == "DeleteGroup")
            {
                groupClient.DeleteGroup(groupSessionObj, e.CommandArgument.ToString());
                LoadAllGroups();
                LoadGroupsToDropDownList(ddlAllGroups);
            }
            else if (e.CommandName == "ShowPeopleInGroup")
            {

               // groupClient.GetGroupMembers(groupSessionObj, e.CommandArgument.ToString());
 foreach (ListViewItem item in lstvw_AllGroups.Items)
                {
Panel pnl_ManagePeople = (Panel)item.FindControl("pnl_ManagePeople");
                pnl_ManagePeople.Visible = false;
                }
 Panel pnl_CurrentManagePeople = (Panel)e.Item.FindControl("pnl_ManagePeople");
 pnl_CurrentManagePeople.Visible = true;
                ListView lstvw_AllPeopleInGroup = (ListView)e.Item.FindControl("lstvw_AllPeopleInGroup");
                Session["Scenario1_CurrentGroup"] = e.CommandArgument.ToString();
                lstvw_AllPeopleInGroup.DataSource = GetGroupPeople(e.CommandArgument.ToString());
                lstvw_AllPeopleInGroup.DataBind();

               

            }
            else if (e.CommandName == "AddPersonToGroup")
            {
                string currentGroupId = Session["Scenario1_CurrentGroup"].ToString();
                TextBox txt_NewPersonId = (TextBox) e.Item.FindControl("txt_NewPersonId");
                  TextBox txt_NewPersonName= (TextBox) e.Item.FindControl("txt_NewPersonName");

                  AddPersonToGroup(currentGroupId, txt_NewPersonId.Text, txt_NewPersonName.Text);
                
                ListView lstvw_AllPeopleInGroup = (ListView)e.Item.FindControl("lstvw_AllPeopleInGroup");
                lstvw_AllPeopleInGroup.DataSource = GetGroupPeople(currentGroupId);
                lstvw_AllPeopleInGroup.DataBind();
            }
            else if (e.CommandName == "GetGroupLatestEvents")
            {
                RenderLatestEvents();
                lbl_selectAGroupForEvents.Visible = false;
            }
           
            //if (e.CommandName == "RemovePersonFromGroup")
            //{
            //    string currentGroupId = Session["Scenario1_CurrentGroup"].ToString();

            //    ListView lstvw_AllPeopleInGroup = (ListView)e.Item.FindControl("lstvw_AllPeopleInGroup");

            //    lstvw_AllPeopleInGroup.DataSource = GetGroupPeople(currentGroupId);
            //    lstvw_AllPeopleInGroup.DataBind();
               
            //}


            
            
            
        }

        protected void AddPersonToGroup(string groupId, string name, string personId)
        {
            SociosServices.SocialFilteringGroupService2.Person newPerson = new SociosServices.SocialFilteringGroupService2.Person();
            newPerson.id = new SociosServices.SocialFilteringGroupService2.ObjectId();
            newPerson.id.id = personId;
            //newPerson.name = new SociosServices.SocialFilteringGroupService2.Name();
            newPerson.displayName = name;
            SociosServices.SocialFilteringGroupService2.Person[] people = new SociosServices.SocialFilteringGroupService2.Person[] { newPerson };

            groupClient.addMembers(groupSessionObj, people, groupId);
            lbl_Notification.Visible = true;
            lbl_Notification.Text += "<p>User '" + personId + "' successfully added to group '" + groupId + "'</p>";
        }

        protected void lstvw_AllPeople_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (e.CommandName == "RemovePersonFromGroup")
            {
                SociosServices.SocialFilteringGroupService2.Person newPerson = new SociosServices.SocialFilteringGroupService2.Person();
                newPerson.id = new SociosServices.SocialFilteringGroupService2.ObjectId();
                newPerson.id.id = e.CommandArgument.ToString();
                SociosServices.SocialFilteringGroupService2.Person[] people = new SociosServices.SocialFilteringGroupService2.Person[] { newPerson };
                string currentGroupId = Session["Scenario1_CurrentGroup"].ToString();
                groupClient.RemoveMembers(groupSessionObj, people, currentGroupId);
                ListView lstvw_AllPeopleInGroup = (ListView)e.Item.Parent.Parent.Parent;
                lstvw_AllPeopleInGroup.DataSource = GetGroupPeople(currentGroupId);
                lstvw_AllPeopleInGroup.DataBind();
             

               

            }
           
        }

        protected void btn_AddPersonToGroup_Click(object sender, EventArgs e)
        {
            AddPersonToGroup(ddlAllGroups.SelectedValue, hdnfld_AddPersonId.Value, hdnfld_AddPersonId.Value);
        }

        protected void btn_AddPersonToNewGroup_Click(object sender, EventArgs e)
        {
           
            string newGroupTitle = txt_AddUser_CreateGroupName.Text;
            string newGroupDescription = txt_AddUser_CreateGroupDescription.Text;
           SociosServices.SocialFilteringGroupService2.Group newGroup = CreateNewGroup(newGroupTitle, newGroupDescription);
            AddPersonToGroup(newGroup.id.id,hdnfld_AddPersonId.Value,hdnfld_AddPersonId.Value);
            LoadAllGroups();
            LoadGroupsToDropDownList(ddlAllGroups);
            lbl_Notification.Visible = true;
            lbl_Notification.Text += "<p>New group '" + txt_AddUser_CreateGroupName.Text + "' successfully created</p>";
      
        }

        protected void lnkbtn_MenuShowSearchMedia_Click(object sender, EventArgs e)
        {
            pnl_ManageGroups.Visible = false;
            pnl_MediaSearch.Visible = true;
        }

        protected void lnkbtn_MenuShowManageGroups_Click(object sender, EventArgs e)
        {
            LoadAllGroups();
            pnl_ManageGroups.Visible = true;
            pnl_MediaSearch.Visible = false;
        }


        protected void RenderLatestEvents()
        {
            int[] userIds = new int[] { 1, 2, 3, 4, 5, 6, 7, 8 };
            SociosServices.EventDetectionService.ActivityList1[] results = eventDetectionClient.GetEvents(userIds);
            lstvw_LatestEvents.DataSource = results;
            lstvw_LatestEvents.DataBind();
        }

        public string RenderEvent(SociosServices.EventDetectionService.Activity[] activities)
        {
            string response = "";
            foreach (SociosServices.EventDetectionService.Activity activity in activities)
            {
                response += "<div class='activity-media-item media-item-" + activity.appId.source.knownSns.ToString().ToLower() + "'>"+

                    "<div class='activity-title'>" + activity.title + "</div>" + "<div class='activity-body'><a href='" + activity.url + "'>" + activity.url + "</a></div></div>";
              //  activity.
             //   response += "<span></span>"
            }

            //SociosServices.EventDetectionService.Activity currentActivity = 
            return response;
        }

        public string GetMediaItemIFrame(SociosServices.WebSkeletonServiceLive.ObjectId id, object itemUrl)
        {
            string url = "http://";
            if (id != null && id.source != null && itemUrl != null)
            {

                if (id.source.Item.ToString().ToLower() == "youtube")
                {

                    string[] attributes = id.id.Split(':');
                    int length = attributes.Length;

                    url += "www.youtube.com/embed/" + attributes[length - 1];
                }
                else if (id.source.Item.ToString().ToLower() == "dailymotion")
                {
                    url += "www.dailymotion.com/embed/video/" + id.id;
                }
                else if (id.source.Item.ToString().ToLower() == "flickr")
                {
                    if (itemUrl != null)
                        url = (string)itemUrl;
                }
                else
                {
                    return "";
                }
                urls.Add(url);
                return "<iframe width=\"560\" height=\"315\" src=\""+url+"\" frameborder=\"0\" allowfullscreen></iframe>";

            }
         
                return "";
      



            
            
            
        }

        protected string  GetPersonReputationScore(string personId)
        {
            double score = 0.0;
          score =  reputationClient.GetPersonReputationScore(personId);
            int test = 0;
            return score.ToString();
        }

        protected SociosServices.RecommendationService.Person[] GetRecommendedPersons(string keywords)
        {
            SociosServices.RecommendationService.Person[] persons = recommendationClient.GetRecommendedPersons(keywords);
            int test = 0;
            return persons;
        }
            


        public string GetMediaItemId(object source, object id)
        {
            string sourceString = "unknownSource";
            if (source as string != null)
            {
                if (((string)source).ToLower() == "youtube")
                {
                    sourceString = "youtube";
                }
                else if (((string)source).ToLower() == "flickr")
                {
                    sourceString = "flickr";
                }
                else if (((string)source).ToLower() == "dailymotion")
                {
                    sourceString = "dailymotion";
                }
                else if (((string)source).ToLower() == "twitter")
                {
                    sourceString = "twitter";
                }
            }
            return sourceString;
        }

         public string GetMediaItemSource(object source)
        {
            try
            { 
                if(source as string != null)
                {
                    if(((string)source).ToLower() == "youtube")
                    {
                        return "youtube";
                    }
                    else if (((string)source).ToLower() == "flickr")
                    {
                        return "flickr";
                    }
                }
            
            
                SociosServices.WebSkeletonServiceLive.KnownSns sourceFormatted = new SociosServices.WebSkeletonServiceLive.KnownSns();

                if (source != null)
                {
                    sourceFormatted = (SociosServices.WebSkeletonServiceLive.KnownSns)source;

                    return sourceFormatted.ToString().ToLower();
                }
                return "no-source-found";
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return error;
            }
         }

         public string GetUserPhotoUrl(string sociosUserInfo)
         {
             try
             {
                 string[] itemUserInfo = sociosUserInfo.ToString().Split(':');
                 if (itemUserInfo.Length > 1)
                 {
                     //string userSnsId =
                     if (itemUserInfo[1].ToLower() == "facebook")
                     {
                         return "http://graph.facebook.com/" + itemUserInfo[0] + "/picture";
                     }
                     else
                     {
                     }

                     //GetProfileUrl(e.CommandArgument.ToString().Split(':')[0], e.CommandArgument.ToString().Split(':')[1]);

                 } return "http://frontend.sociosproject.eu/images/no-profile.png";
             }
             catch (Exception ex)
             {
                 string message = ex.Message;
                 return ex.Message;
             }
         }

         protected string GetProfileUrl()
         {
             string userId = "13403905@N03";
             SkeletonServiceClient client = new SociosServices.SkeletonServiceClient();
            string profileUrl = client.GetPersonUsername(userId);
            return profileUrl;

         }

         protected void CheckAccessTokensStatus()
         {
             SociosServices.TokenServiceClient tokenClient = new TokenServiceClient();
             tokenClient.SetUserAccessToken(99, 2, "testAccessTokenFromFrontEnd");
            
         }

         protected void lnkbtn_RefreshAccess_Click(object sender, EventArgs e)
         {
             SociosServices.TokenServiceClient tokenClient = new TokenServiceClient();
          accessInfo[] info =  tokenClient.GetUserTokens(Convert.ToInt32(txtUserId.Text));
          Dictionary<int, string> snsIdsList = new Dictionary<int, string>(); 
             if (info != null)
             {
                 lbl_AccessInfo.Text = "";
                 
                 int i = 0; // number of tokens found
                 
                 foreach (accessInfo token in info)
                 {
                     snsIdsList.Add(token.accessInfoPK.snsId, token.accessToken);
                 }

              
          }else {
                     lbl_AccessInfo.Text = "<br/>No access tokens available for user: "+txtUserId.Text;
             }
             //string[] snsNames = { "facebook", "twitter", "flickr", "youtube", "dailymotion" };
             Dictionary<int, string> allSnsNamesInts = new Dictionary<int, string>();
             allSnsNamesInts.Add(1, "flickr");
             allSnsNamesInts.Add(2, "facebook");
             allSnsNamesInts.Add(3, "twitter");
             allSnsNamesInts.Add(4, "youtube");
             allSnsNamesInts.Add(6, "dailymotion");
            // List<string> snsNamesList = new List<string>(snsNames);
            //int[] snsIds = { 1, 2, 3, 4, 5, 6 };
            // List<int> snsIdsList = new List<int>(snsIds); 
             foreach (KeyValuePair<int,string> snName in allSnsNamesInts)
             {
                 bool tokenAvailable = false;
                 string accessToken = "";
                 if (info != null)
                 {
                     
                         if (snsIdsList.ContainsKey( snName.Key))
                         {
                             tokenAvailable = true;
                             //accessToken = token.accessToken;
                         }
                    
                 }
                 if (tokenAvailable)
                 {
                     lbl_AccessInfo.Text += "<img alt='" + accessToken + "'  src='DesktopModules/Socios_Scenario1/Images/" + snName.Value.ToLower() + ".png'/>";

                 }
                 else
                 {
                     lbl_AccessInfo.Text += "<img alt='" + accessToken + "' src='DesktopModules/Socios_Scenario1/Images/" + snName.Value.ToLower() + "-bw.png'/>";
                 }
                     
             }
         }

         protected void lnkbtn_GetConnectedPeople_Click(object sender, EventArgs e)
         {
             SkeletonServiceClient client = new SociosServices.SkeletonServiceClient();
             List<SociosServices.WebSkeletonServiceLive.KnownSns> sources = new List<SociosServices.WebSkeletonServiceLive.KnownSns>();
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.DAILYMOTION);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.FACEBOOK);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.FLICKR);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.MYSPACE);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.TWITTER);
                sources.Add(SociosServices.WebSkeletonServiceLive.KnownSns.YOUTUBE);
         SociosServices.WebSkeletonServiceLive.Person[] persons =   client.GetConnectedPersons("", sources);
         int test = 1;
         lstvwConnectedPersons.DataSource = persons;
         lstvwConnectedPersons.DataBind();
         }

      


    }


}

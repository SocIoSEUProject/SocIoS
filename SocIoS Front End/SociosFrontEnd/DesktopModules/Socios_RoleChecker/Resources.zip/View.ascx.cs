/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using DotNetNuke.Common;
using DotNetNuke.Security.Roles;
using System.Web;


namespace DotNetNuke.Modules.Socios_RoleChecker
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewSocios_RoleChecker class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Socios_RoleCheckerModuleBase, IActionable
    {

        #region Event Handlers

        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }
// localhost 90
                // frontend 88
        int ROLESELECTOR_TABID = 88;
        int MEDIASEARCH_TABID = 66;
        int PLAYER_HOMEPAGE_TABID = 89;
        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                
                
                if (TabId == ROLESELECTOR_TABID)
                {
                    
                }
                    // We are on any other page, and we need to check if the user has a socios role.
                else
                {pnlAll.Visible = false;
                    if (UserId > 0)
                    {
                        // Checking user role
                        if (!(UserInfo.IsInRole("Players") || UserInfo.IsInRole("Candidates") || UserInfo.IsInRole("Journalists")))
                        {
                            string currentUrl = HttpContext.Current.Request.Url.AbsoluteUri;
                            Response.Redirect(Globals.NavigateURL(ROLESELECTOR_TABID) + "?redirectUrl=" + HttpUtility.UrlEncode(currentUrl), true);
                        }

                    }
                }

            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        #endregion

        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

        protected void hprlnk_Jounalist_Click(object sender, EventArgs e)
        {
            AssignRoleToUser("Journalists", Globals.NavigateURL( MEDIASEARCH_TABID));
        }

        protected void hprlnk_Candidate_Click(object sender, EventArgs e)
        {
            AssignRoleToUser("Candidates", Globals.NavigateURL(MEDIASEARCH_TABID));
        }

        protected void hprlnk_Player_Click(object sender, EventArgs e)
        {
            AssignRoleToUser("Players", Globals.NavigateURL(PLAYER_HOMEPAGE_TABID));
        }




        protected void AssignRoleToUser(string roleName, string redirectTo)
        {
            //Get the role information
            RoleController cntrl = new RoleController();
            RoleInfo roleInfo = cntrl.GetRoleByName(this.PortalId, roleName);

            // Clearing all roles allows the user to switch between roles
            RoleInfo roleInfoJournalist = cntrl.GetRoleByName(this.PortalId, "Journalists");
            RoleInfo roleInfoPlayer = cntrl.GetRoleByName(this.PortalId, "Players");
            RoleInfo roleInfoCandidate = cntrl.GetRoleByName(this.PortalId, "Candidates");

           RoleController.DeleteUserRole(UserInfo, roleInfoJournalist,PortalSettings, false);
           RoleController.DeleteUserRole(UserInfo, roleInfoPlayer, PortalSettings, false);
           RoleController.DeleteUserRole(UserInfo, roleInfoCandidate, PortalSettings, false);



            //Assign to user
            cntrl.AddUserRole(this.PortalId, UserId, roleInfo.RoleID, System.DateTime.Now.AddDays(-1), DotNetNuke.Common.Utilities.Null.NullDate);
            if(redirectTo != "")
                Response.Redirect(redirectTo);
            else if (Request.QueryString["redirectUrl"] != null)
                Response.Redirect(HttpUtility.UrlDecode(Request.QueryString["redirectUrl"]));
            else
                Response.Redirect("/");
        }

    }

}

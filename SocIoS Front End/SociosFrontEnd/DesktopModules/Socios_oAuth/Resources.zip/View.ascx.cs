/*
' Copyright (c) 2010  DotNetNuke Corporation
'  All rights reserved.
' 
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
' DEALINGS IN THE SOFTWARE.
' 
*/

using System;
using DotNetNuke.Services.Exceptions;
using DotNetNuke.Entities.Modules;
using DotNetNuke.Entities.Modules.Actions;
using DotNetNuke.Services.Localization;
using DotNetNuke.Security;
using System.Net;
using System.Text;
using System.IO;
using System.Diagnostics;
using DotNetOpenAuth.OAuth;
using DotNetOpenAuth.ApplicationBlock;
using System.Data.SqlClient;
using DotNetNuke.Common.Utilities;
using SociosServices;


namespace DotNetNuke.Modules.Socios_oAuth
{

    /// -----------------------------------------------------------------------------
    /// <summary>
    /// The ViewSocios_oAuth class displays the content
    /// </summary>
    /// -----------------------------------------------------------------------------
    public partial class View : Socios_oAuthModuleBase, IActionable
    {
        //private SqlConnection CN = new SqlConnection(Config.GetConnectionString("SiteSqlServer"));
        #region Event Handlers

        override protected void OnInit(EventArgs e)
        {
            InitializeComponent();
            base.OnInit(e);
        }

        private void InitializeComponent()
        {
            this.Load += new System.EventHandler(this.Page_Load);
        }

        enum OAuthServiceProviders { YouTube=1, Twitter=2, Facebook=3, DailyMotion=4};

        string CONSUMER_KEY = "dKzWF4UspzgVXl31dNhw";
        string CONSUMER_SECRET = "rftX05xlV7CcnBqhCPgk9AhgeHeBpdDUObgqgTSbOBE";
        /// -----------------------------------------------------------------------------
        /// <summary>
        /// Page_Load runs when the control is loaded
        /// </summary>
        /// -----------------------------------------------------------------------------
        private void Page_Load(object sender, System.EventArgs e)
        {
            try
            {
                SociosServices.TokenServiceClient tokenClient = new TokenServiceClient();
                if (Session["YouTubeAccessToken"] != null)
                {
                    lbl_YouTubeAccessToken.Text = Session["YouTubeAccessToken"].ToString();

                   // CN.Open();
                   // string ssql = @"
                   // INSERT INTO Socios_AccessTokens (ProviderID, AccessToken, UserID, Date)
                   // VALUES ('" + oauth + "', " + UserId + ", getdate() ," + CurrentItem.Value + " )";
                   // SqlCommand cmSQL = new SqlCommand(ssql, cn);
                   // cmSQL.ExecuteNonQuery();
                   // CN.Close();
                    div_youtube_status.Attributes["class"] = "youtube_active";
                    img_youtube.Visible = true;

                }

                if (Session["TwitterAccessToken"] != null)
                {
                    string twitterAccessToken = Session["TwitterAccessToken"].ToString();
                    lbl_TwitterAccessToken.Text = twitterAccessToken;

                    string twitterAccessTokenSecret = Session["TwitterAccessTokenSecret"].ToString();
                    lbl_TwitterAccessTokenSecret.Text = twitterAccessTokenSecret;
                   
                    string toSaveToDatabase = CONSUMER_KEY + "@" + CONSUMER_SECRET + "@" + twitterAccessToken + "@" + twitterAccessTokenSecret;

                    tokenClient.SetUserAccessToken(99, 3, toSaveToDatabase);

                    div_twitter_status.Attributes["class"] = "twitter_active";
                    img_twitter.Visible = true;
                }

                if (Session["FacebookAccessToken"] != null)
                {
                    lbl_FacebookAccessToken.Text = Session["FacebookAccessToken"].ToString();
                   
                    tokenClient.SetUserAccessToken(99, 2, Session["FacebookAccessToken"].ToString());
                    div_facebook_status.Attributes["class"] = "facebook_active";
                    img_facebook.Visible = true;
                }
                if (Session["DailymotionAccessToken"] != null)
                {
                    lbl_DailymotionAccessToken.Text = Session["DailymotionAccessToken"].ToString();
                    div_dailymotion_status.Attributes["class"] = "dailymotion_active";
                    img_dailymotion.Visible = true;
                }
                if (Session["FlickrAccessToken"] != null)
                {
                    string flickrAccessToken = Session["FlickrAccessToken"].ToString();
                    lbl_FlickrAccessToken.Text = flickrAccessToken;
                    tokenClient.SetUserAccessToken(99, 1, flickrAccessToken);
                    div_flickr_status.Attributes["class"] = "flickr_active";
                    img_flickr.Visible = true;
                }

               // Session["FacebookAccessToken"] = "testaccess";
            }
            catch (Exception exc) //Module failed to load
            {
                Exceptions.ProcessModuleLoadException(this, exc);
            }
        }

        #endregion

        #region Optional Interfaces

        public ModuleActionCollection ModuleActions
        {
            get
            {
                ModuleActionCollection Actions = new ModuleActionCollection();
                Actions.Add(GetNextActionID(), Localization.GetString("EditModule", this.LocalResourceFile), "", "", "", EditUrl(), false, SecurityAccessLevel.Edit, true, false);
                return Actions;
            }
        }

        #endregion

        protected void lnkbtn_YouTube_Click(object sender, EventArgs e)
        {
            Session["CurrentOAuthProcessed"] = "youtube";
            Response.Redirect("OAuthTokenManager.aspx");
        }

       
        protected void lnkbtn_Twitter_Click(object sender, EventArgs e)
        {
            Session["CurrentOAuthProcessed"] = "twitter";
            Response.Redirect("OAuthTokenManager.aspx");
        }

        protected void lnkbtn_Facebook_Click(object sender, EventArgs e)
        {
            Session["CurrentOAuthProcessed"] = "facebook";
            Response.Redirect("OAuthTokenManager.aspx");
        }


        protected void lnkbtn_Dailymotion_Click(object sender, EventArgs e)
        {
            Session["CurrentOAuthProcessed"] = "dailymotion";
            Response.Redirect("OAuthTokenManager.aspx");
        }

        protected void lnkbtn_Flickr_Click(object sender, EventArgs e)
        {
            Session["CurrentOAuthProcessed"] = "flickr";
            Response.Redirect("OAuthTokenManager.aspx");
        }

    }

}

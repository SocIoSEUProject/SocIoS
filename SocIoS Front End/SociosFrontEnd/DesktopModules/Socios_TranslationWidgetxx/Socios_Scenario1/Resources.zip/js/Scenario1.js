﻿$(document).ready(function () {
    // $('#contact-user-form').fadeOut();

    $('.green-info-box').delay(500).fadeIn('fast').delay(3000).fadeOut();

    $('.message-user').click(function () {
        // $('#contact-user-form').dialog({ modal: true, minHeight: 0, title: 'Contact user', show: "fadeIn", hide: "fadeOut" });

        var dialog = $(this).parent().find(".user-consent-form").dialog({ modal: true, minHeight: 0, title: 'Contact user', show: "fadeIn", hide: "fadeOut" });
        dialog.parent().appendTo(jQuery("form:first"));
    })



    $('.add-user').click(function () {

        var usernameToAdd = $(this).parent().parent().find('.author-username span').html();


        $('#AddPersonIdAnchorElement').next().val(usernameToAdd);
        var dialog = $('#add-to-group-form').dialog({ modal: true, minHeight: 0, title: 'Add user to a group', show: "fadeIn", hide: "fadeOut" });
        dialog.parent().appendTo(jQuery("form:first"));
    })

    $('.remove-user').click(function () {
        $('#remove-from-group-form').dialog({ modal: true, minHeight: 0, title: 'Remove user from a group', show: "fadeIn", hide: "fadeOut" });
    })

    $('.media-item-thumb').click(function () {
        var test2 = $(this);
        var test1 = $(this).next();
        var test3 = $(this).next().find(".view-media-item");
        $(this).next().find(".view-media-item").dialog({ modal: true, minHeight: 0, width: '580px', title: 'Media item view', show: "fadeIn", hide: "fadeOut" });
    })

    $('[title="contact-user"]').live('click', function () {
        $('#user-consent-form').dialog({ modal: true, minHeight: 0, width: '580px', title: 'User contact form', show: "fadeIn", hide: "fadeOut" });
    })

    $('[title="request-consent-user"]').live('click', function () {
        $('#user-consent-form').dialog({ modal: true, minHeight: 0, width: '580px', title: 'User consent request form', show: "fadeIn", hide: "fadeOut" });
    })

    //    $('#contact-user-form input').get(1).click(function () {
    //        $('#user-consent-form').dialog({ modal: true, minHeight: 0, width: '580px', title: 'User consent request form', show: "fadeIn", hide: "fadeOut" });
    //    })



});
